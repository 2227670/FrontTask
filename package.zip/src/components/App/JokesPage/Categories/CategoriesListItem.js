import React, {Component} from "react";
import {connect} from 'react-redux'
import {categoriesLoaded, jokesLoaded} from '../../../../actions/actions'

class CategoriesListItem extends Component {
    render() {

        const getJokes = (categoryName) => {
            fetch('https://api.chucknorris.io/jokes/random?category=' + categoryName)
                .then(res => res.json())
                .then(
                    (result) => {
                        this.props.jokesLoaded(result)
                        // console.log(result)
                        // console.log(this.props.joke.value)
                    }
                )
                .catch(error => console.log(error))
        }

        const {category} = this.props
        return (
            <div style={{
                border: '1px solid black',
                display: 'inline-block'
            }}>
                <h3>{category}</h3>
                <button onClick={() => getJokes(category)}>Get jokes</button>
            </div>
        )
    }
}


const mapStateToProps = (state) => {
    return {
        categories: state.categories,
        loading: state.loading,
        joke: state.joke
    }
}

const mapDispatchToProps = {
    jokesLoaded
}

export default connect(mapStateToProps, mapDispatchToProps)(CategoriesListItem)