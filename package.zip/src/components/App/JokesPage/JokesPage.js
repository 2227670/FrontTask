import React, {Component} from "react";
import {connect} from "react-redux"

import CategoriesList from "./Categories/CategoriesList";
import JokesList from "./Jokes/JokesList";
import {jokesLoaded} from "../../../actions/actions";

class JokesPage extends Component {

    componentDidMount() {
        for (let i = 0; i <= 5; i++) {
            fetch('https://api.chucknorris.io/jokes/random')
                .then(res => res.json())
                .then(
                    (result) => {

                        let newJoke = {
                            id: result.id,
                            value: result.value
                        }

                        let jokes = []
                        jokes = this.props.jokes
                        jokes.push(newJoke)

                        this.props.jokesLoaded(jokes)

                        // //jokes = this.props.joke
                        // jokes.push(result)
                        // console.log(typeof (this.props.joke))
                        // console.log(typeof (jokes))
                        // this.props.jokesLoaded(jokes)
                        // console.log('iterr nr: ' + i)
                        // //console.log(this.props.joke)

                    },
                    (error) => {
                        //ToDO error processing for categories list
                    }
                )
        }
    }

    render() {
        return (
            <div>
                <CategoriesList/>
                <JokesList/>
            </div>
        );
    }
}

//ToDo make list with random jokes

const mapStateToProps = (state) => {
    return {
        jokes: state.jokes
    }
}

const mapDispatchToProps = {
    jokesLoaded
}

export default connect(mapStateToProps, mapDispatchToProps)(JokesPage)