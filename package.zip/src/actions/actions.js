const categoriesLoaded = (categories) => {
    return {
        type: 'CATEGORIES_LOADED',
        payload: categories
    }
}

const jokesLoaded = (joke) => {
    return {
        type: 'JOKES_LOADED',
        payload: joke
    }
}

export {
    categoriesLoaded,
    jokesLoaded
}