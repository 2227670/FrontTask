import React, {Component} from "react";
import {connect} from 'react-redux'
import {jokesLoaded} from '../../../../actions/actions'
import JokesListItem from './JokesListItem'
import CategoriesListItem from "../Categories/CategoriesListItem";

class JokesList extends Component {

    render() {
        const {jokes, loading} = this.props

        if (loading) {
            return (<h1>LOADING..</h1>)
        }
        console.log(jokes)
        return (
            <div style={{
                display: "block"
            }}>
                <h1>List of jokes</h1>
                {/*<JokesListItem key={joke.id} joke={joke.value}/>*/}
                {jokes.map(joke => {
                    console.log(joke.value)
                    return <JokesListItem key={joke.id} joke={joke.value}/>
                })}

            </div>
        )
    }
}


const mapStateToProps = (state) => {
    return {
        jokes: state.jokes,
        loading: state.loading
    }
}


export default connect(mapStateToProps, null)(JokesList)


// {categories ? categories.map(category => {
//     return <CategoriesListItem key={category} category={category}/>
// }) : null}
