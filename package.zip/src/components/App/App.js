import React, {Component} from "react";
import {BrowserRouter as Router, Route} from "react-router-dom";
import {connect} from "react-redux"
import Header from "../Header/Header";
import About from "../About/About";
import Favourites from "../Favourites/Favourites";

import CategoriesList from "./JokesPage/Categories/CategoriesList";
import JokesList from "./JokesPage/Jokes/JokesList";
import JokesPage from "./JokesPage/JokesPage";


class App extends Component {

    componentDidMount() {

    }

    render() {

        return (
            <Router>
                <div>
                    <Header/>
                    <Route path='/' exact component={JokesPage}/>
                    <Route path='/about' exact component={About}/>
                    <Route path='/favourites' exact component={Favourites}/>
                </div>
            </Router>
        )
    }
}

// const mapStateToProps = (state) => {
//     return {
//         loading: state.loading,
//         joke: state.joke
//     }
// }

export default App

// const {error, isLoaded, categories} = this.state;
// if (error) {
//     return <div>Error: {error.message}</div>;
// } else if (!isLoaded) {
//     return <div>Loading...</div>;
// } else {
//     //console.log(categories)
//     return (
//         <div>
//             <h1>All is good {categories[1]}</h1>
//             <CategoriesList categories={categories}/>
//         </div>
//     )
// }