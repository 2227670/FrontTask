import React, {Component} from "react";
import CategoriesListItem from "./CategoriesListItem";
import {connect} from 'react-redux'
import {categoriesLoaded} from '../../../../actions/actions'

class CategoriesList extends Component {

    componentDidMount() {
        fetch('https://api.chucknorris.io/jokes/categories')
            .then(res => res.json())
            .then(
                (result) => {
                    this.props.categoriesLoaded(result)
                },
                (error) => {
                    //ToDO error processing for categories list
                }
            )
    }

    render() {
        const {categories, loading} = this.props

        if (loading) {
            return (<h1>LOADING..</h1>)
        }
        return (
            <div>
                <h1>List of categories</h1>
                {categories ? categories.map(category => {
                    return <CategoriesListItem key={category} category={category}/>
                }) : null}
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        categories: state.categories,
        loading: state.loading,
    }
}

const mapDispatchToProps = {
    categoriesLoaded
}

export default connect(mapStateToProps, mapDispatchToProps)(CategoriesList)


{/*{props&&props.categories.map(category => (*/
}
{/*    <CategoriesListItem categoryName={category}/>*/
}
{/*))}*/
}


// return {
//     categoriesLoaded: (categories) => {
//         dispatch({
//             type: 'CATEGORIES_LOADED',
//             payload: categories
//         })
//     }
// }