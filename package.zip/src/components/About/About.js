import React, {Component} from "react";

function About(props) {

    return (
        <div>
            <h1>About Page</h1>
        </div>
    );
}

export default About