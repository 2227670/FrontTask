import React, {Component} from "react";

function Favourites(props) {

    return (
        <div>
            <h1>Favourites Page</h1>
        </div>
    );
}

export default Favourites