import React, {Component} from "react";

class JokesListItem extends Component {
    render() {

        const {joke} = this.props
        return (
            <div style={{
                border: '1px solid black',
                display: 'inline-block'
            }}>
                <h3>{joke}</h3>
                <button>like</button>
            </div>
        )
    }
}

export default JokesListItem