import React from 'react';
import './header.css';
import {Link} from 'react-router-dom';

const Header = () => {
    return (
        <div className="header">
            <h3 className="header-title">
                <Link to='/'>
                    Chuck Norris API
                </Link>
            </h3>
            <ul className="header-list">

                <li>
                    <Link to='/'>Home</Link>
                </li>
                <li>
                    <Link to='/about/'>About</Link>
                </li>
                <li>
                    <Link to='/favourites/'>Favourites</Link>
                </li>
            </ul>
        </div>
    );
};

export default Header;