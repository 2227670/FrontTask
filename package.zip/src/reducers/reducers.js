const initialState = {
    categories: [],
    loading: true,
    jokes: [
        {
            id: "ye0_hnd3rgq68e_pfvsqqg",
            value: "Chuck Norris can instantiate an abstract class."
        },
        {
            id: "ye0_hnd3rgq68e_hjkqqg",
            value: "Chuck Norris can instantiate an abstract class."
        }
    ]
}

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case 'CATEGORIES_LOADED':
            return {
                ...state,
                categories: action.payload,
                loading: false
            };
        case 'JOKES_LOADED':
            return {
                ...state,
                jokes: action.payload,
                loading: false
            };
        default:
            return state
    }
}

export default reducer


